-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2023 at 08:54 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sourcecodester_mysqli`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbadministrators`
--

CREATE TABLE `tbadministrators` (
  `admin_id` int(5) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbadministrators`
--

INSERT INTO `tbadministrators` (`admin_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'Admin', 'admin', 'admin@example.com', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'admin', 'admin', 'admin@example.com', 'admin'),
(3, '', '', '', '29e457082db729fa1059d4294ede3909'),
(4, 'AJAY', 'kumae', 'ajay@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Table structure for table `tbcandidates`
--

CREATE TABLE `tbcandidates` (
  `candidate_id` int(5) NOT NULL,
  `candidate_name` varchar(45) NOT NULL,
  `candidate_position` varchar(45) NOT NULL,
  `candidate_cvotes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbcandidates`
--

INSERT INTO `tbcandidates` (`candidate_id`, `candidate_name`, `candidate_position`, `candidate_cvotes`) VALUES
(3, 'Luis Nani', 'President', 13),
(4, 'Wayne Rooney', 'President', 22),
(8, 'Michael Walters', 'Secretary', 10),
(9, 'Roberto Mancini', 'Secretary', 47),
(10, 'Alex Ferguson', 'Treasurer', 0),
(13, 'Chemical Reaction', 'Treasurer', 0),
(15, 'Paul Allen', 'Organizing-Secretary', 4),
(16, 'Bill Gates', 'Organizing-Secretary', 5),
(23, 'Akande', 'Academic', 0),
(24, 'Opeyemi', 'Academic', 1),
(25, 'Daniel', 'Financial', 1),
(26, 'Badmus', 'Financial', 0),
(27, 'Funmi', 'Gen', 1),
(28, 'Hannah', 'Gen', 0),
(29, 'Usman', 'Public', 0),
(30, 'Tope', 'Public', 1),
(31, 'Akeem', 'sport', 0),
(32, 'happiness', 'sport', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblvotes`
--

CREATE TABLE `tblvotes` (
  `id` int(11) NOT NULL,
  `voter_id` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `candidateName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblvotes`
--

INSERT INTO `tblvotes` (`id`, `voter_id`, `position`, `candidateName`) VALUES
(1, 5, 'President', 'Luis Nani'),
(2, 5, 'Vice-Secretary', 'Thomas Vaemalen'),
(3, 5, 'Secretary', 'Michael Walters'),
(4, 5, 'Treasurer', 'Howard Web'),
(5, 5, 'HOD', 'Aman'),
(6, 7, 'Chairperson', 'Wayne Rooney'),
(7, 7, 'Secretary', 'Michael Walters'),
(8, 14, 'Secretary', 'Roberto Mancini'),
(9, 14, 'Organizing-Secretary', 'Bill Gates'),
(10, 14, 'President', 'Wayne Rooney'),
(11, 14, 'Treasurer', 'Richard Santana'),
(12, 14, 'Financial', 'Daniel'),
(13, 14, 'Public', 'Tope'),
(14, 14, 'Academic', 'Opeyemi'),
(15, 15, 'Gen', 'Funmi'),
(16, 14, 'sport', 'happiness'),
(17, 16, 'President', 'Luis Nani'),
(18, 16, 'sport', 'happiness'),
(19, 17, 'President', 'Luis Nani');

-- --------------------------------------------------------

--
-- Table structure for table `tbmembers`
--

CREATE TABLE `tbmembers` (
  `member_id` int(5) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbmembers`
--

INSERT INTO `tbmembers` (`member_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'Kimani', 'Kahiga', 'kahiga@gmail.com', '547da2b03f947606f1d06a8dec093e64'),
(2, 'MacDonald', 'Ngowi', 'mcbcrue08@gmail.com', '14b876400a7ae986df9b17fbaffb9eca'),
(3, 'test', 'testt', 'test@example.com', '098f6bcd4621d373cade4e832627b4f6'),
(5, 'Ajay', 'Chaubey', 'ajaychaubey95@gmail.com', '202cb962ac59075b964b07152d234b70'),
(6, 'anil', 'k', 'anil@gmail.com', '202cb962ac59075b964b07152d234b70'),
(7, 'AWOLORO', 'Daniel', 'oluwajuwonloadedayo69@gmail.com', '0c29ba43d9ceee56def441180a5fbbb4'),
(8, 'AWOLORO', 'Daniel', 'oluwajuwonloadedayo69@gmail.com', '0c29ba43d9ceee56def441180a5fbbb4'),
(9, 'AWOLORO', 'Daniel', 'oluwajuwonloadedayo69@gmail.com', '0c29ba43d9ceee56def441180a5fbbb4'),
(10, 'AWOLORO', 'Daniel', 'oluwajuwonloadedayo69@gmail.com', 'c238542b5811806fc1702fdc9cbf0965'),
(11, 'Adeniran', 'Johnson', 'oluwajuwonloadedayo69@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759'),
(12, 'Adeniran', 'Johnson', 'oluwajuwonloadedayo69@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759'),
(13, 'Adeniran', 'Johnson', 'oluwajuwonloadedayo69@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759'),
(14, 'Awoloro', 'Iyanuoluwa', 'aduragbemi@example.com', '0f281d173f0fdfdccccd7e5b8edc21f1'),
(15, 'Adisa', 'Opeyemi', 'adedayo@example.com', 'b5ea8985533defbf1d08d5ed2ac8fe9b'),
(16, 'oluniran ', 'Samuel', 'oluwajuwon@example.com', '0eee42bcd146101e5a270fa879c09bf8'),
(17, 'Adedayo', 'dayo', 'samuelmofopefoluwa@gmail.com', 'b79d01ca35fceb474ebbb7302f785494');

-- --------------------------------------------------------

--
-- Table structure for table `tbpositions`
--

CREATE TABLE `tbpositions` (
  `position_id` int(5) NOT NULL,
  `position_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbpositions`
--

INSERT INTO `tbpositions` (`position_id`, `position_name`) VALUES
(1, 'President'),
(2, 'Secretary'),
(7, 'Organizing-Secretary'),
(8, 'Treasurer'),
(12, 'Academic Officer'),
(13, 'Financial Secretary'),
(14, 'Gen Secretary'),
(15, 'Public Relational Officer'),
(16, 'sport director');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbadministrators`
--
ALTER TABLE `tbadministrators`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbcandidates`
--
ALTER TABLE `tbcandidates`
  ADD PRIMARY KEY (`candidate_id`);

--
-- Indexes for table `tblvotes`
--
ALTER TABLE `tblvotes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `voter_id` (`voter_id`);

--
-- Indexes for table `tbmembers`
--
ALTER TABLE `tbmembers`
  ADD PRIMARY KEY (`member_id`);

--
-- Indexes for table `tbpositions`
--
ALTER TABLE `tbpositions`
  ADD PRIMARY KEY (`position_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbadministrators`
--
ALTER TABLE `tbadministrators`
  MODIFY `admin_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbcandidates`
--
ALTER TABLE `tbcandidates`
  MODIFY `candidate_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tblvotes`
--
ALTER TABLE `tblvotes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbmembers`
--
ALTER TABLE `tbmembers`
  MODIFY `member_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbpositions`
--
ALTER TABLE `tbpositions`
  MODIFY `position_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblvotes`
--
ALTER TABLE `tblvotes`
  ADD CONSTRAINT `tblvotes_ibfk_1` FOREIGN KEY (`voter_id`) REFERENCES `tbmembers` (`member_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
