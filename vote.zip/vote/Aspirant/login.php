<html>  
<head>
<link href="css/form.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="js/admin.js">
</script>
</head><body style="background-color: #FFF;">
<div id="page">
<div id="header">
<!-- <center><h1 style="margin-top: 3%; color:#61876E;">ASPIRANT LOGIN </h1></center> -->
<p align="center">&nbsp;</p>
</div>
<div id="container" style=" width: 600px; height: 400px;  background-color: #fff;  box-shadow: 0 2px 10px rgba(0,0,0,0.3); margin-left: 32%;  " >
<table width="300" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<form name="form1" method="post" action="aspirant.php" onsubmit="return loginValidate(this)">
<center><h3 style="font-size: 25px; margin-top: 25%; color: #61876E; padding-top: 10%">log in as an aspirant</h3></center>
<td>
<table width="100%" border="0" style="margin-top: 3%;" cellpadding="3" cellspacing="1" >
<tr>
<td width="78" style="margin-left: 5%; font-size:19px;">Username/Email</td>
<td width="6">:</td>
<td width="294"><input name="myusername" style=' font-weight:bold; width: 20vw; height: 5vh; margin-top: 16px;'  type="text" id="myusername"></td>
</tr>
<tr>
<td style="margin-left: 5%; font-size:19px;">Password</td>
<td>:</td>
<td><input name="mypassword" type="password" style=' font-weight:bold; width: 20vw; height: 5vh; margin-top: 16px;'  id="mypassword"></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><input type="submit" name="Submit" value="Login"  style='margin-top: 2rem; width: 100%; margin-left: -9%; height:5vh; background-color:#61876E;  color:white; border: none;' ></td>
</tr>
</table>
</td>
</form>
</tr>
</table>
<center>
</center>
</div>

</div>
</body></html>