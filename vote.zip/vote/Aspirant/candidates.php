<style>
    nav{
    display: flex;
    height: 4rem;
    justify-content: space-between;
    text-transform: uppercase;
    padding: 0 1rem;
    background:#AECFA4;
    color: #fff;
    /* margin-top: 1rem; */
   
}
#nav-bar a{
    /* color: #f2f2f2; */
    padding: 10px;
}
ul{
    display: flex;
    text-decoration: none;
    margin-top: 1.5%; 
    margin-right: 5%;
    
}

li{
    display: inline;
    margin-right: 1px;
    text-decoration: none;
    color: #fff
    

}
h3{
    text-align: center;
    margin-left: 3%;
}
h1{
    text-align: center;
}
a{
    text-decoration: none;
    color: #fff;
}
</style>

















<?php
session_start();
require('../connection.php');
//If your session isn't valid, it returns you to the login screen for protection
// if(empty($_SESSION['admin_id'])){
//  header("location:access-denied.php");
// } 
//retrive candidates from the tbcandidates table
$result=mysqli_query($con,"SELECT * FROM tbCandidates");
if (mysqli_num_rows($result)<1){
    $result = null;
}
?>
<?php
// retrieving positions sql query
$positions_retrieved=mysqli_query($con, "SELECT * FROM tbPositions");
/*
$row = mysqli_fetch_array($positions_retrieved);
 if($row)
 {
 // get data from db
 $positions = $row['position_name'];
 }
 */
?>
<?php
$con = mysqli_connect("localhost","root", "", "sourcecodester_mysqli")or die ("Error: " .mysqli_error($con));


$newCandidateName = addslashes( $_POST['name'] ); //prevents types of SQL injection
$newCandidatePosition = addslashes( $_POST['position'] ); //prevents types of SQL injection


$sql = mysqli_query($con, "INSERT INTO tbCandidates(candidate_name,candidate_position) VALUES ('$newCandidateName','$newCandidatePosition')" );

// redirect back to candidates
// echo"<script>alert('Confirmed')</script>";

//  header("Location: candidates.php");

?>

<?php
// deleting sql query
// check if the 'id' variable is set in URL
 if (isset($_GET['id']))
 {
 // get id value
 $id = $_GET['id'];
 
 // delete the entry
 $result = mysqli_query($con, "DELETE FROM tbCandidates WHERE candidate_id='$id'");
 
 // redirect back to candidates
 header("Location: candidates.php");
 }
 else
 // do nothing   
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Administration Control Panel:Candidates</title>
<link href="style.css" rel="stylesheet"  />
<script language="JavaScript" src="js/admin.js">
</script>
</head>
<body>

<div id="page">
<div id="header">
<header><div id="nav-bar">
      
      <nav>
          <h3> Voting<span>System</span></h3> 
          <ul>
              <div class="li-con">
                  <li><a href="aspirant.php" class="home" style="color: white;">Home</a></li>
              
              <li><a href="candidates.php" style="color: white;">Canditates</a></li>
              <li><a href="refresh.php">Results</a></li>
              <li><a href="../home.php" >LogOut</a></li>
              </div>
              
          </ul>
      </nav>
  </div></header>
  <h1  style="margin-top:4%;">MANAGE CANDIDATES</h1>

</div>
<div id="container">
<table width="380" align="center">
<CAPTION><h3>ADD NEW CANDIDATE</h3></CAPTION>
<form name="fmCandidates" id="fmCandidates" action="" method="post" onsubmit="return candidateValidate(this)">
<tr>
    <td><p style="margin-top:4%;">Candidate Name</p> </td>
    <td><input type="text" name="name" style="width: 30vw; height: 5vh; margin-left: 4%;" /></td>
</tr>
<tr>
    <td>Candidate Position</td>
    <!--<td><input type="combobox" name="position" value="<?php echo $positions; ?>"/></td>-->
    <td><SELECT NAME="position" id="position" style="width: 30vw; height: 5vh; margin-top: 3%; margin-left: 4%;">select
    <OPTION VALUE="select">select
    <?php
    //loop through all table rows
    while ($row=mysqli_fetch_array($positions_retrieved)){
    echo "<OPTION VALUE=$row[position_name]>$row[position_name]";
    //mysql_free_result($positions_retrieved);
    //mysql_close($link);
    }
    ?>
    </SELECT>
    </td>
</tr>
<tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="Submit" value="Add" onclick="myfunction()" style=" background-color: #AECFA4; color: white; width: 15vw; height: 5vh;  margin-top:2%; cursor:pointer; margin-left: 30%;"  /></td>
</tr>
</table>

<table border="0" width="620" align="center">
<!-- <CAPTION><h3>AVAILABLE CANDIDATES</h3></CAPTION> -->
<!-- <tr>
<th  style=" border: 1px solid black;height: 8vh; width: 45vw; text-align: center;">Candidate ID</th>
<th  style=" border: 1px solid black;height: 8vh; width: 45vw; text-align: center;">Candidate Name</th>
<th style=" border: 1px solid black;height: 8vh; width: 45vw; text-align: center;">Candidate Position</th>
<!-- <th style=" border: 1px solid black;height: 8vh; width: 45vw; text-align: center;">Action</th> -->
</tr> 

<!--  -->
</table>
<!-- <hr> -->
</div>
<div id="footer"> 
  <!-- <div class="bottom_addr">&copy; 2023 Voting System. All Rights Reserved</div> -->
</div>
</div>
</body>
</html>
<script>
    function myfunction(){
        window.alert('Wait Till Admin Approve Your Post')
    }

</script>