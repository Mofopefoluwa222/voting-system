<html><head>

<script language="JavaScript" src="js/user.js">
</script>
</head>
<body  style="background-color:#AECFA4" >

<div id="page">
<div id="header">

<center><h1  style="color:#fff; margin-top: 5%;"> Student Login </h1></center>

</div>
<div id="container" style=" width: 480px; height: 300px;  background-color: #fff;  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0, 0.19); margin-left: 32%;  ">
<table width="300"  align="center" cellpadding="0" cellspacing="1" >
<tr>
    <center><h3 style="font-size: 25px;">LOG IN</h3></center>
<form name="form1" method="post" action="checklogin.php" onSubmit="return loginValidate(this)">
<td>
<table width="100%"    >
<tr>
    
<td style="margin-left:24rem; font-size: 19px;">Username/Email</td>
<td>:</td>
<td><input name="myusername" style="width: 20vw; height: 5vh; margin-top: 16px;"type="text" id="myusername"></td>
</tr>
<tr>
<td style="font-size: 19px;">Password</td>
<td>:</td>
<td><input name="mypassword" type="password" id="mypassword" style="width: 20vw; height: 5vh; margin-top: 16px;"></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><input type="submit" name="Submit" value="Login" style='margin-top: 1rem; width: 13vw; height:5vh; margin-left:-8%; background-color:#AECFA4;  color:white; border: none;'></td>
</tr>
</table>
</td>
</form>
</tr>
</table>
<center>
<br>Not yet registered? <a style="text-decoration: none; color: black;" href="registeracc.php"><b>Register Here</b></a>
</center>
</div>

</div>
<!-- <?php include('footer.php')?> -->
</body></html>