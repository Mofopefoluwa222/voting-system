<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<style>
        
</style>
<body>
    <section class="one" id="one">
    <header>
        <span>
         <img src="images/sug.JPG" alt="" class="sug">
        </span>
           <nav>
            <ul>
                <div class="head">
                 <a href="#one" id="home"> <li> HOME</li></a> 
                 <a href="#about-page" id="about"> <li> ABOUT</li></a> 
                 <a href="#footer" id="contact"> <li> CONTACT</li></a> 
                 <a href="admin/index.php"><li>ADMIN</li></a>
                
                
            </div>
          </ul>
           </nav>
    </header>

    <div class="half">
        <div class="content">
            <h2> S U G </h2>
            <h4>Online voting system</h4> 
            <div class="login_candidate">
            <a href="aspirant/login.php" id="aspirant"> <li> login as an aspirant</li></a> 
            <a href="index.php" id="voter"> <li> login as a voter</li></a> 
            </div>
        </div>
    </div> 
    <img src="images/9814.jpg" alt="" class="left-image">
    </div>
    </div>
   
    </section>

    <!-- About-section -->

    <section class="about-section" id="about-page">
        <h1>
            <span>A</span>
            <span>B</span>
            <span>O</span>
            <span>U</span>
            <span>T</span>
        </h1>
        <div class="about">
            <div class="about-img">

            </div>
            <div class="about-text">
                <p>
                    Welcome to our online voting website! Here you can participate in elections, 
                    cast your ballot, and make your voice heard. We are committed to providing you 
                    with a safe and secure voting experience. We strive to ensure that the voting process 
                    is fair, transparent, and accessible to all. Thank you for visiting and we hope you enjoy 
                    the experience.
                </p>
            </div>
        </div>
    </section>


        <!-- section.third -->
        <section class="third">
            <img src="images/images.png" alt="" id="line">
            
           
            
        </section>



        <!-- fotter area -->
       <section class="footer-section">
        <div class="footer" id="footer">
            <div class="quick-link">
                <h6>QUICK LINK</h6>
                <a href="#one" id="home"> <li> HOME</li></a> 
                 <a href="#about-page" id="about"> <li> ABOUT</li></a> 
                 <a href="" id="contact"> <li>CONTACT</li></a> 
            </div>
            <div class="extra-link">
                <h6>EXTRA LINK</h6>
                <a href="./form.html"> <li> LOGIN AS ASPIRANT</li></a> 
                <a href="./form.html"> <li> LOGIN AS VOTER</li></a> 
            </div>
            <div class="contact-info">
                <h6>CONTACT INFO</h6>
                <li><i class="fa fa-phone"></i>+234-8159-234-164</li>
                <li><i class="fa fa-phone"></i>+234-9026-994-285</li>
                <li><i class="fa fa-envelope"></i>samuelmofopefoluwa@gmail.com</li>
            </div>
            <div class="follow-us">
                <h6>FOLLOW US</h6>
                <li><i class="fa-brands fa-facebook-f"></i>FACEBOOK</li>
                <li><i class="fa-brands fa-twitter"></i>TWITTER</li>
                <li><i class="fa-brands fa-instagram"></i>INSTAGRAM</li>
            </div>
            
        </div>
        <hr>
        <p class="p15">
            &copy; copyright @ 2023 by <span>Oluniran Samuel Mofopefoluwa</span>
        </p>
       </section>
</html>