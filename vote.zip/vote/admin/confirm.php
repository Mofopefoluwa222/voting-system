<!-- 
<?php
$con = mysqli_connect("localhost","root", "", "sourcecodester_mysqli")or die ("Error: " .mysqli_error($con));


    
$newCandidateName = $_POST['name'] ; //prevents types of SQL injection
$newCandidatePosition =  $_POST['position']; //prevents types of SQL injection


$sql = mysqli_query($con, "INSERT INTO tbCandidates(candidate_name,candidate_position) VALUES ('$newCandidateName','$newCandidatePosition')" );

// redirect back to candidates
// echo"<script>alert('Confirmed')</script>";

//  header("Location: candidates.php");
echo"<script>alert('Confirmed')
window.alert='candidates.php'
</script>";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <input type="hidden" name="name">
    <input type="hidden" name="position">
</body>
</html> -->