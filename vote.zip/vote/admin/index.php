<html><head>
<!-- <link href="css/admin_styles.css" rel="stylesheet" type="text/css" /> -->
<script language="JavaScript" src="js/admin.js">
</script>
</head><body style="background-color: #AECFA4;">
<div id="page">
<div id="header">
<center><h1 style="margin-top: 3%; color:white;">Administrator Login </h1></center>
<p align="center">&nbsp;</p>
</div>
<div id="container" style=" width: 480px; height: 300px;  background-color: #fff;  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0, 0.19); margin-left: 32%;  " >
<table width="300" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<form name="form1" method="post" action="checklogin.php" onsubmit="return loginValidate(this)">
<center><h3 style="font-size: 25px; margin-top: 5%;">LOG IN</h3></center>
<td>
<table width="100%" border="0" style="margin-top: 3%;" cellpadding="3" cellspacing="1" >
<tr>
<td width="78" style="margin-left: 5%; font-size:19px;">Username/Email</td>
<td width="6">:</td>
<td width="294"><input name="myusername" style='  width: 20vw; height: 5vh; margin-top: 16px;'  type="text" id="myusername"></td>
</tr>
<tr>
<td style="margin-left: 5%; font-size:19px;">Password</td>
<td>:</td>
<td><input name="mypassword" type="password" style=' font-weight:bold; width: 20vw; height: 5vh; margin-top: 16px;'  id="mypassword"></td>
</tr>
<tr>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><input type="submit" name="Submit" value="Login"  style='margin-top: 2rem; width: 13vw; margin-left: -9%; height:5vh; background-color:#AECFA4;  color:white; border: none;' ></td>
</tr>
</table>
</td>
</form>
</tr>
</table>
<center>
</center>
</div>

</div>
</body></html>