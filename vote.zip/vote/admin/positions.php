<?php
session_start();
require('../connection.php');
//If your session isn't valid, it returns you to the login screen for protection
if(empty($_SESSION['admin_id'])){
 header("location:access-denied.php");
}
//retrive positions from the tbpositions table
$result=mysqli_query($con, "SELECT * FROM tbPositions");
if (mysqli_num_rows($result)<1){
    $result = null;
}
?>
<?php
// inserting sql query
if (isset($_POST['Submit']))
{

$newPosition = addslashes( $_POST['position'] ); //prevents types of SQL injection

$sql = mysqli_query($con, "INSERT INTO tbpositions (position_name) VALUES ('$newPosition')");

// redirect back to positions
 header("Location: positions.php");
}
?>
<?php
// deleting sql query
// check if the 'id' variable is set in URL
 if (isset($_GET['id']))
 {
 // get id value
 $id = $_GET['id'];
 
 // delete the entry
 $result = mysqli_query($con, "DELETE FROM tbPositions WHERE position_id='$id'");
 
 // redirect back to positions
 header("Location: positions.php");
 }
 else
 // do nothing
    
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="style2.css">
<title>Administration Control Panel:Positions</title>
<!-- <link href="css/admin_styles.css" rel="stylesheet" type="text/css" /> -->
<script language="JavaScript" src="js/admin.js">
</script>
</head>
<body>

<div id="page">
<div id="header">
<header><div id="nav-bar">
      
      <nav>
          <h3> Voting<span>System</span></h3> 
          <ul>
              <div class="li-con">
                  <li><a href="admin.php" class="home" style="color: white;">Home</a></li>
              <li><a href="positions.php" style="color: white;">Manage Positions</a></li>
              <li><a href="candidates.php" style="color: white;">Manage Canditates</a></li>
              <li><a href="refresh.php">Results</a></li>
              <li><a href="manage-admins.php" >Manage Account</a></li>
              <li><a href="change-pass.php" >Change Password</a></li>
              <li><a href="logout.php" >LogOut</a></li>
              </div>
              
          </ul>
      </nav>
  </div></header>
  <h1>MANAGE POSITIONS</h1>

</div>
<div id="container">
<table width="380" align="center">
<CAPTION><h3>ADD NEW POSITION</h3></CAPTION>
<form name="fmPositions" id="fmPositions" action="positions.php" method="post" onsubmit="return positionValidate(this)">
<tr>
    <td style="font-size: 19px; margin-left: -50%;">Position Name </td>
    <td><input type="text" style="width: 30vw; height: 5vh;" name="position" /></td>
    <td><input type="submit" style="margin-left: 10%; background-color: #AECFA4; color: white; width: 10vw; height: 5vh;" name="Submit" value="Add" /></td>
</tr>
</table>
<hr>
<table border="0" width="420" align="center">
<CAPTION><h3>AVAILABLE POSITIONS</h3></CAPTION>
<tr>
<th style=" border: 1px solid black;
    height: 6vh;width: 45vw; ">Position ID</th>
<th style=" border: 1px solid black;
    height: 6vh;width: 45vw;">Position Name</th>
<th style=" border: 1px solid black; height: 6vh;width: 55vw;">Action</th>
</tr>

<?php
//loop through all table rows
$inc=1;
while ($row=mysqli_fetch_array($result)){
echo "<tr>";
echo "<td style=' border: 1px solid black;height: 6vh; text-align: center; width: 45vw;'>" .$inc."</td>";
echo "<td  style=' border: 1px solid black;height: 6vh; margin-left: 12%; text-align: center; width: 45vw;'>" . $row['position_name']."</td>";
echo '<td  style=" border: 1px solid black;height: 8vh; width: 45vw; text-align: center;"><button style="background-color: red; height:5vh; border: none; border-radius: 6px;"><a href="positions.php?id=' . $row['position_id'] . '">Delete Position</a></button></td>';
echo "</tr>";
$inc++;
}

mysqli_free_result($result);
mysqli_close($con);
?>
</table>
<hr>
</div>
<div id="footer"> 
  <div class="bottom_addr">&copy; 2023 Voting System. All Rights Reserved</div>
</div>
</div>
</body>
</html>