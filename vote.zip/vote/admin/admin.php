<?php
session_start();
require('../connection.php');
//If your session isn't valid, it returns you to the login screen for protection
if(empty($_SESSION['admin_id'])){
 header("location:access-denied.php");
}
?>
<html><head>
    <link rel="stylesheet" href="style.css">
<!-- <link href="css/admin_styles.css" rel="stylesheet" type="text/css" /> -->
</head><body >

<div id="page">
<div id="header">
<header><div id="nav-bar">
      
      <nav>
          <h3> Voting<span>System</span></h3> 
          <ul>
              <div class="li-con">
                  <li><a href="admin.php" class="home">Home</a></li>
              <li><a href="positions.php">Manage Positions</a></li>
              <li><a href="candidates.php">Manage Canditates</a></li>
              <li><a href="refresh.php">Results</a></li>
              <li><a href="manage-admins.php">Manage Account</a></li>
              <li><a href="change-pass.php">Change Password</a></li>
              <li><a href="../home.php">LogOut</a></li>
              </div>
              
          </ul>
      </nav>
  </div></header>
  <center><h1 style="margin-top: 10%;">WELCOME</h1></center>
  <center><h1>TO</h1></center>
<h1>ADMINISTRATION CONTROL PANEL </h1>
<!-- <a href="admin.php">Home</a> | <a href="positions.php">Manage Positions</a> | <a href="candidates.php">Manage Candidates</a> | <a href="refresh.php">Poll Results</a> | <a href="manage-admins.php">Manage Account</a> | <a href="change-pass.php">Change Password</a>  | <a href="logout.php">Logout</a> -->
</div>
<p align="center">&nbsp;</p>
<div id="container">

<center><p style="font-size: 19px;">Click a link above to perform an administrative operation.</p></center>


</div>
<div id="footer">
<!-- <div class="bottom_addr">&copy; 2012 Simple PHP Polling System. All Rights Reserved</div> -->
</div>
</div>
</body></html>