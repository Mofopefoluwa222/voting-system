<?php
session_start();
require('../connection.php');
?>
<html><head>
<link href="style.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="js/admin.js">
</script>
</head><body>

<div id="page">
<div id="header">
<header><div id="nav-bar">
      
      <nav>
          <h3> Voting<span>System</span></h3> 
          <ul>
              <div class="li-con">
                  <li><a href="admin.php" class="home" style="color: white;">Home</a></li>
              <li><a href="positions.php" style="color: white;">Manage Positions</a></li>
              <li><a href="candidates.php" style="color: white;">Manage Canditates</a></li>
              <li><a href="refresh.php">Results</a></li>
              <li><a href="manage-admins.php" >Manage Account</a></li>
              <li><a href="change-pass.php" >Change Password</a></li>
              <li><a href="../home.php" >LogOut</a></li>
              </div>
              
          </ul>
      </nav>
  </div></header>
<h1>MANAGE ADMINISTRATORS </h1>

</div>
<div id="container" style=" width: 460px; height: 320px;  margin-top: 3%; background-color: #fff;  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0, 0.19); margin-left: 32%;  font-size:20px; ">
<?php
//If your session isn't valid, it returns you to the login screen for protection
if(empty($_SESSION['admin_id'])){
 header("location:access-denied.php");
}

//fetch data for update file
$result=mysqli_query($con, "SELECT * FROM tbadministrators WHERE admin_id = '$_SESSION[admin_id]'");
if (mysqli_num_rows($result)<1){
    $result = null;
}
$row = mysqli_fetch_array($result);
if($row)
 {
 // get data from db
 $encPass = $row['password'];
 }

//Process
if (isset($_GET['id']) && isset($_POST['update']))
{
    $myId = addslashes( $_GET['id']);
    $mypassword = md5($_POST['oldpass']);
    $newpass= $_POST['newpass'];
    $confpass= $_POST['confpass'];
    if($encPass==$mypassword)
    {
        if($newpass==$confpass)
        {
        $newpass = md5($newpass); //This will make your password encrypted into md5, a high security hash
        $sql = mysqli_query($con, "UPDATE tbadministrators SET password='$newpass' WHERE admin_id = '$myId'" );
        echo "<script>alert('Your password updated');</script>";
        }
        else
        {
            echo "<script>alert('Your new pass and confirm pass not match');</script>";
        }    
    }
    else
    {
        echo "<script>alert('Your old pass not match');</script>";
    }
    
}
?>
<table align="center">
<tr>
<td>
<form action="change-pass.php?id=<?php echo $_SESSION['admin_id']; ?>" method="post" onSubmit="return updateProfile(this)">
<table align="center">
<CAPTION><h4>CHANGE PASSWORD</h4></CAPTION>
<tr><td>Old Password:</td><td><input type="password" style=" font-weight:bold;  width: 20vw; height: 5vh; margin-top: 16px; " name="oldpass" maxlength="15" value=""></td></tr>
<tr><td>New Password:</td><td><input type="password" style="font-weight:bold;  width: 20vw; height: 5vh; margin-top: 16px;" name="newpass" maxlength="15" value=""></td></tr>
<tr><td>Confirm Password:</td><td><input type="password" style="font-weight:bold;  width: 20vw; height: 5vh; margin-top: 16px;" name="confpass" maxlength="15" value=""></td></tr>
<tr><td>&nbsp;</td><td><input type="submit" name="update" value="Update Account" style="margin-top: 2rem; width: 13vw; height:5vh; background-color:#AECFA4; margin-left:-7%; color:white; border: none;"></td></tr>
</table>
</form>
</td>
</tr>
</table>
</div>
<div id="footer">
<!-- <div class="bottom_addr">&copy; 2012 Simple PHP Polling System. All Rights Reserved</div> -->
</div>
</div>
</body></html>