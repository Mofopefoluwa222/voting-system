<?php
session_start();
require('../connection.php');
//If your session isn't valid, it returns you to the login screen for protection
if(empty($_SESSION['admin_id'])){
 header("location:access-denied.php");
} 
//retrive candidates from the tbcandidates table
$result=mysqli_query($con,"SELECT * FROM tbCandidates");
if (mysqli_num_rows($result)<1){
    $result = null;
}
?>
<?php
// retrieving positions sql query
$positions_retrieved=mysqli_query($con, "SELECT * FROM tbPositions");
/*
$row = mysqli_fetch_array($positions_retrieved);
 if($row)
 {
 // get data from db
 $positions = $row['position_name'];
 }
 */
?>


<?php
// deleting sql query
// check if the 'id' variable is set in URL
 if (isset($_GET['id']))
 {
 // get id value
 $id = $_GET['id'];
 
 // delete the entry
 $result = mysqli_query($con, "DELETE FROM tbCandidates WHERE candidate_id='$id'");
 
 // redirect back to candidates
 header("Location: candidates.php");
 }
 else
 // do nothing   
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Administration Control Panel:Candidates</title>
<link href="style2.css" rel="stylesheet" type="text/css" />
<script language="JavaScript" src="js/admin.js">
</script>
</head>
<body>

<div id="page">
<div id="header">
<header><div id="nav-bar">
      
      <nav>
          <h3> Voting<span>System</span></h3> 
          <ul>
              <div class="li-con">
                  <li><a href="admin.php" class="home" style="color: white;">Home</a></li>
              <li><a href="positions.php" style="color: white;">Manage Positions</a></li>
              <li><a href="candidates.php" style="color: white;">Manage Canditates</a></li>
              <li><a href="refresh.php">Results</a></li>
              <li><a href="manage-admins.php" >Manage Account</a></li>
              <li><a href="change-pass.php" >Change Password</a></li>
              <li><a href="../home.php" >LogOut</a></li>
              </div>
              
          </ul>
      </nav>
  </div></header>
  <h1>MANAGE CANDIDATES</h1>

</div>
<div id="container">
<table width="380" align="center">
<!-- <CAPTION><h3>ADD NEW CANDIDATE</h3></CAPTION>
<form name="fmCandidates" id="fmCandidates" action="candidates.php" method="post" onsubmit="return candidateValidate(this)">
<tr>
    <td><p style="margin-top:4%;">Candidate Name</p> </td>
    <td><input type="text" name="name" style="width: 30vw; height: 5vh; margin-left: 4%;" /></td>
</tr> -->
<!-- <tr>
    <!-- <td>Candidate Position</td>
    <!--<td><input type="combobox" name="position" value="<?php echo $positions; ?>"/></td>-->
    <!-- <td><SELECT NAME="position" id="position" style="width: 30vw; height: 5vh; margin-top: 3%; margin-left: 4%;">select
    <OPTION VALUE="select">select
    
    //loop through all table rows
    // while ($row=mysqli_fetch_array($positions_retrieved)){
    // echo "<OPTION VALUE=$row[position_name]>$row[position_name]";
    // //mysql_free_result($positions_retrieved);
    // //mysql_close($link);
    // }
    ?> -->
    </SELECT>
    </td>
</tr>
<tr>
    <td>&nbsp;</td>
    
</tr>
</table>
<P>Confirm if any post is being made <button class="butt" onclick="myfunction()" class="butt" name="confirmed">Confirm </button></P>
<table border="0" width="620" align="center">
<CAPTION><h3>AVAILABLE CANDIDATES</h3></CAPTION>
<tr>
<th  style=" border: 1px solid black;height: 8vh; width: 45vw; text-align: center;">Candidate ID</th>
<th  style=" border: 1px solid black;height: 8vh; width: 45vw; text-align: center;">Candidate Name</th>
<th style=" border: 1px solid black;height: 8vh; width: 45vw; text-align: center;">Candidate Position</th>
<th style=" border: 1px solid black;height: 8vh; width: 45vw; text-align: center;">Action</th>
</tr>

<?php
//loop through all table rows
$inc=1;
while ($row=mysqli_fetch_array($result)){
    
echo "<tr>";
echo "<td style=' border: 1px solid black;height: 8vh; width: 45vw; text-align: center;'>" . $inc."</td>";
echo "<td  style=' border: 1px solid black;height: 8vh; width: 45vw; text-align: center;'>" . $row['candidate_name']."</td>";
echo "<td  style=' border: 1px solid black;height: 8vh; width: 45vw; text-align: center;'>" . $row['candidate_position']."</td>";
echo '<td  style=" border: 1px solid black;height: 8vh; width: 45vw; text-align: center;" ><button style="background-color: red; height:5vh; border: none; border-radius: 6px;"><a href="candidates.php?id=' . $row['candidate_id'] . '">Delete Candidate</a></button></td>';
echo "</tr>";
$inc++;
}

mysqli_free_result($result);
mysqli_close($con);
?>
</table>
<hr>
</div>
<div id="footer"> 
  <div class="bottom_addr">&copy; 2023 Voting System. All Rights Reserved</div>
</div>
</div>
</body>
</html>
<script>
    function myfunction(){
        window.alert("Confirmed")
    }
</script>
<style>
    p{
        margin-left: 400px;
        font-size:20px;
    }
    .butt{
        margin-left:23px;
        width: 8vw;
        height: 5vh;
        border-radius: 6px;
        border:none;
        background-color: #AECFA4;
        color: #fff;
    }
</style>